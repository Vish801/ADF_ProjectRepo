# ADF_ProjectRepo
This ADF project created for Topgear challenge.

Created 3 triggers to trigger the job on Daily, Weekly, and Monthly Basis. The files for these will be picked from respective Sharepoint location and place it into Azure Data lake storage gen2. 
